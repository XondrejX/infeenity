// components
import PricingView from 'src/sections/pricing/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Pricing',
};

export default function PricingPage() {
  return <PricingView />;
}
