// sections
import { FaqsView } from 'src/sections/faqs/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Faqs',
};

export default function FaqsPage() {
  return <FaqsView />;
}
