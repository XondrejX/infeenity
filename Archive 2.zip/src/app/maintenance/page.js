// sections
import MaintenanceView from 'src/sections/maintenance/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Maintenance',
};

export default function MaintenancePage() {
  return <MaintenanceView />;
}
