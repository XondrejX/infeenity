// sections
import { PaymentView } from 'src/sections/payment/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Payment',
};

export default function PaymentPage() {
  return <PaymentView />;
}
