export { default as ConfirmDialog } from './confirm-dialog';
